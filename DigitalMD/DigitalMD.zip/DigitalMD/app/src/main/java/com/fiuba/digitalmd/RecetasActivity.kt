package com.fiuba.digitalmd

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class RecetasActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_recetas)
    }
}
