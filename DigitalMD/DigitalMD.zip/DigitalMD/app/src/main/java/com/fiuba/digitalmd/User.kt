package com.fiuba.digitalmd

class User  (val name:String, val urlImage:String) {
}